<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
  <div class="container-fluid">
    <div class="collapse navbar-collapse" id="navbarNav">
      <ul class="navbar-nav">
        <li class="nav-item">
          <a class="nav-link active" aria-current="page" href="./index.php">Inicio</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="./ciudades.php">Ciudades</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="./eventos.php">Eventos</a>
        </li>

      </ul>
    </div>
  </div>
</nav>

