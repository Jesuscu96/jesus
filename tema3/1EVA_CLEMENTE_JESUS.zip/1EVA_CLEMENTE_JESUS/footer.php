</main> <!-- Cierre del <main> iniciado en index.php o libro.php -->
  </div> <!-- Cierre de .row -->
</div> <!-- Cierre de .container-fluid -->

<footer class="bg-dark text-white text-center py-3 mt-4">
    &copy; 2025 Librería Online - Todos los derechos reservados
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
